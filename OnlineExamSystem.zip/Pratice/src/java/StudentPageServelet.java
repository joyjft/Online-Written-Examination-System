/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Joy
 */
@WebServlet(urlPatterns = {"/StudentPageServelet"})
public class StudentPageServelet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {

            String clickedOn = request.getParameter("peB");
            String clickedOn2 = request.getParameter("smB");
            String clickedOn3 = request.getParameter("uiB");
            String un = request.getParameter("username");
            String c = null;
//            System.out.println(clickedOn+" "+clickedOn2+" "+clickedOn3);
            if (clickedOn == null && clickedOn2 == null) {
                c = clickedOn3;
            }
            if (clickedOn3 == null && clickedOn2 == null) {
                c = clickedOn;

            }
            if (clickedOn == null && clickedOn3 == null) {
                c = clickedOn2;

            }

//             request.setAttribute("username", un);
//
//            if (c.equals("create_exam")) {
//                request.getRequestDispatcher("createExamPage.jsp").forward(request, response);
//            }
            System.out.println(c);
            request.setAttribute("username", un);
            if (c.equals("perform_exam")) {
                System.out.println("i1");
                request.getRequestDispatcher("performExamPage.jsp").forward(request, response);

            }
            if (c.equals("see_mark")) {
                try {
                    System.out.println("i2");

                    String q = "SELECT distinct(e_id) FROM JOYJFT.MARK where STUDENT=?";
                    Connection con = null;
                    PreparedStatement ps = null;
                    ResultSet rs = null;

                    Class.forName("org.apache.derby.jdbc.ClientDriver");
                    con = DriverManager.getConnection("jdbc:derby://localhost:1527/MyDB", "joyjft", "12345");
                    ps = con.prepareStatement(q);
                    ps.setString(1, un);

                    rs = ps.executeQuery();
                    ArrayList<String> exams = new ArrayList<String>();

                    while (rs.next()) {

                        //Retrieve by column name
                        exams.add(rs.getString("e_id"));
                        System.out.println(rs.getString("e_id"));

                    }
                    request.setAttribute("exams", exams);

                    System.out.println("hellow");

                    request.getRequestDispatcher("seeMarkPage.jsp").forward(request, response);
                } catch (Exception e) {
                    e.printStackTrace();
                }

                request.getRequestDispatcher("seeMarkPage.jsp").forward(request, response);

            }
            String n = null;
            String e = null;
            String pass = null;
            if (c.equals("update_info")) {
                
                String q = "SELECT * FROM JOYJFT.STUDENT where username=?";
                Connection con = null;
                PreparedStatement ps = null;
                ResultSet rs = null;

                Class.forName("org.apache.derby.jdbc.ClientDriver");
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/MyDB", "joyjft", "12345");
                ps = con.prepareStatement(q);
                ps.setString(1, un);

                rs = ps.executeQuery();
               

                while (rs.next()) {
                    n=rs.getString("name");
                    e=rs.getString("email");
                    pass=rs.getString("password");
                    System.out.println(n+" "+e+" "+pass);
                    

                }
                request.setAttribute("username", un);
                request.setAttribute("name", n);
                request.setAttribute("email", e);
                request.setAttribute("password", pass);

                System.out.println("update");

                
                request.getRequestDispatcher("updateInfoPageStudent.jsp").forward(request, response);

            }

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(StudentPageServelet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(StudentPageServelet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(StudentPageServelet.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(StudentPageServelet.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
