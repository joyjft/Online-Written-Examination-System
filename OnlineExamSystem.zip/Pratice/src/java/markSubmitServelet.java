/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Joy
 */
@WebServlet(urlPatterns = {"/markSubmitServelet"})
public class markSubmitServelet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            /* TODO output your page here. You may use following sample code. */
            String mark=request.getParameter("mark");
            String sname=request.getParameter("sname");
            String eid=request.getParameter("eid");
            
            String msg=insertMark(eid, sname, mark);
            
            
            
            
            
//            <input  type = "hidden" name = "sname" value = "<%=sname%>"
//                    > <input 
//            type = "hidden" name = "eid" value = "<%=eid%>"
//                    >
            
            
            
            
            out.println("<!DOCTYPE html>\n"
                    + "<html lang=\"en\">\n"
                    + "    <head>\n"
                    + "        <title>Login</title>\n"
                    + "        <meta charset=\"UTF-8\">\n"
                    + "        <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n"
                    + "        <!--===============================================================================================-->	\n"
                    + "        <link rel=\"icon\" type=\"image/png\" href=\"images/icons/favicon.ico\"/>\n"
                    + "        <!--===============================================================================================-->\n"
                    + "        <link rel=\"stylesheet\" type=\"text/css\" href=\"vendor/bootstrap/css/bootstrap.min.css\">\n"
                    + "        <!--===============================================================================================-->\n"
                    + "        <link rel=\"stylesheet\" type=\"text/css\" href=\"fonts/font-awesome-4.7.0/css/font-awesome.min.css\">\n"
                    + "        <!--===============================================================================================-->\n"
                    + "        <link rel=\"stylesheet\" type=\"text/css\" href=\"fonts/iconic/css/material-design-iconic-font.min.css\">\n"
                    + "        <!--===============================================================================================-->\n"
                    + "        <link rel=\"stylesheet\" type=\"text/css\" href=\"vendor/animate/animate.css\">\n"
                    + "        <!--===============================================================================================-->	\n"
                    + "        <link rel=\"stylesheet\" type=\"text/css\" href=\"vendor/css-hamburgers/hamburgers.min.css\">\n"
                    + "        <!--===============================================================================================-->\n"
                    + "        <link rel=\"stylesheet\" type=\"text/css\" href=\"vendor/animsition/css/animsition.min.css\">\n"
                    + "        <!--===============================================================================================-->\n"
                    + "        <link rel=\"stylesheet\" type=\"text/css\" href=\"vendor/select2/select2.min.css\">\n"
                    + "        <!--===============================================================================================-->	\n"
                    + "        <link rel=\"stylesheet\" type=\"text/css\" href=\"vendor/daterangepicker/daterangepicker.css\">\n"
                    + "        <!--===============================================================================================-->\n"
                    + "        <link rel=\"stylesheet\" type=\"text/css\" href=\"css/util.css\">\n"
                    + "        <link rel=\"stylesheet\" type=\"text/css\" href=\"css/main.css\">\n"
                    + "        <!--===============================================================================================-->\n"
                    + "    </head>\n"
                    + "    <body>\n"
                    + "\n"
                    + "        <div class=\"limiter\">\n"
                    + "            <div class=\"container-login100\" style=\"background-image: url('images/bg-01.jpg');\">\n"
                    + "                <div class=\"wrap-login100 p-l-55 p-r-55 p-t-65 p-b-54\">\n"
                    + "                    <form class=\"login100-form validate-form\">\n"
                    + "                        <span class=\"login100-form-title p-b-49\">\n"
                    + msg
                    + "                        </span>\n"
                    + "                        \n"
                    + "\n"
                    + "                    </form>\n"
                    + "                </div>\n"
                    + "            </div>\n"
                    + "        </div>\n"
                    + "\n"
                    + "\n"
                    + "        <div id=\"dropDownSelect1\"></div>\n"
                    + "\n"
                    + "        <!--===============================================================================================-->\n"
                    + "        <script src=\"vendor/jquery/jquery-3.2.1.min.js\"></script>\n"
                    + "        <!--===============================================================================================-->\n"
                    + "        <script src=\"vendor/animsition/js/animsition.min.js\"></script>\n"
                    + "        <!--===============================================================================================-->\n"
                    + "        <script src=\"vendor/bootstrap/js/popper.js\"></script>\n"
                    + "        <script src=\"vendor/bootstrap/js/bootstrap.min.js\"></script>\n"
                    + "        <!--===============================================================================================-->\n"
                    + "        <script src=\"vendor/select2/select2.min.js\"></script>\n"
                    + "        <!--===============================================================================================-->\n"
                    + "        <script src=\"vendor/daterangepicker/moment.min.js\"></script>\n"
                    + "        <script src=\"vendor/daterangepicker/daterangepicker.js\"></script>\n"
                    + "        <!--===============================================================================================-->\n"
                    + "        <script src=\"vendor/countdowntime/countdowntime.js\"></script>\n"
                    + "        <!--===============================================================================================-->\n"
                    + "        <script src=\"js/main.js\"></script>\n"
                    + "\n"
                    + "    </body>\n"
                    + "</html>");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

    
    private String insertMark(String eid, String name, String mark) {
        System.out.println(eid +  name + mark);

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "INSERT INTO JOYJFT.MARK(E_ID, STUDENT, MARK) VALUES(?,?,?)";
       
        try {
            String msg = null;
            Class.forName("org.apache.derby.jdbc.ClientDriver");

            con = DriverManager.getConnection("jdbc:derby://localhost:1527/MyDB", "joyjft", "12345");
            ps = con.prepareStatement(query);
            ps.setString(1, eid);
            ps.setString(2, name);
            ps.setString(3, mark);
           
            ps.executeUpdate();

            return "Mark submission Successfull";

        } catch (Exception ex) {
            ex.printStackTrace();
            return "Failure";

        }
    }
}


