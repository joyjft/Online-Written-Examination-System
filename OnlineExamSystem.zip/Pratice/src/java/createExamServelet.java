/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Joy
 */
@WebServlet(urlPatterns = {"/createExamServelet"})
public class createExamServelet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            String eid=request.getParameter("eid");
            String un=request.getParameter("username");
            String n=request.getParameter("n");
            int num=Integer.parseInt(n);
            System.out.println(eid+'\t'+un+'\t'+n);
            String s=null;
            for (int i = 1; i <= num; i++) {
                
                System.out.println(request.getParameter("q"+i)+'\t'+request.getParameter("m"+i));
                s=insertIntoQuestion(eid,un,request.getParameter("q"+i),request.getParameter("m"+i),"0");
            }
           
                request.setAttribute("username", un);
                request.setAttribute("exam_id", eid);
                request.getRequestDispatcher("examHandler.jsp").forward(request, response);
            
            
            
            
            
        }
    }
    
        private String insertIntoQuestion(String eid, String tname, String ques, String mark,String status) {
        System.out.println(eid + tname + ques + mark +status);

        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "insert into JOYJFT.QUESTION (e_id, t_name, question, mark,status) values (?, ?, ?, ?,?)";
       
        try {
            String msg = null;
            Class.forName("org.apache.derby.jdbc.ClientDriver");

            con = DriverManager.getConnection("jdbc:derby://localhost:1527/MyDB", "joyjft", "12345");
            ps = con.prepareStatement(query);
            ps.setString(1, eid);
            ps.setString(2, tname);
            ps.setString(3, ques);
            ps.setString(4, mark);
            ps.setString(5, status);
            ps.executeUpdate();

            return "Successfull";

        } catch (Exception ex) {
            ex.printStackTrace();
            return "Database Failure";

        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
