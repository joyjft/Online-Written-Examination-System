
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.HashSet;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Joy
 */
public class temp {

    public static void main(String[] args) {
//        System.out.println(get());
            String a=insertIntoTeacher("joy","jjj","kkk","lll");
            System.out.println(a);
    }

    public static String get() {

        Connection con = null;
        Statement sm = null;
        ResultSet rs = null;
        String q = "SELECT * FROM JOYJFT.USERINFO";
        String dbUn = null;
        String dbP = null;
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/MyDB", "joyjft", "12345");
            sm = con.createStatement();
            rs = sm.executeQuery(q);

            while (rs.next()) {
                //Retrieve by column name

                dbUn = rs.getString("username");
                dbP = rs.getString("password");

                //Display values
                System.out.print(", First: " + dbUn);
                System.out.println(", Last: " + dbP);
            }

        } catch (Exception e) {
            System.out.println("Hellow Failure");
        }

        return dbUn;

    }

    public static void match(String name,String password) {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String q = "SELECT * FROM JOYJFT.USERINFO WHERE USERNAME=? AND PASSWORD=?";
        String dbUn = null;
        String dbP = null;
        try {
            String msg=null;
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/MyDB", "joyjft", "12345");
            ps = con.prepareStatement(q);
            ps.setString(1, name);
            ps.setString(2, password);
            rs=ps.executeQuery();
            if(rs.next()) msg="Successfull";
            else msg="Invalid Login";

        } catch (Exception ex) {

        }

    }
    
      private static String insertIntoTeacher(String name, String email, String username, String pass) {
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String query = "insert into JOYJFT.TEACHER (name, username, email, password) values (?, ?, ?, ?)";

        String dbUn = null;
        String dbP = null;
        try {
            String msg = null;
            Class.forName("org.apache.derby.jdbc.ClientDriver");

            con = DriverManager.getConnection("jdbc:derby://localhost:1527/MyDB", "joyjft", "12345");
            ps = con.prepareStatement(query);
            ps.setString(1, name);
            ps.setString(2, username);
            ps.setString(3, email);
            ps.setString(4, pass);

            ps.executeQuery();
            return "Successfull";

        } catch (Exception ex) {
            ex.printStackTrace();
            return "Failure";

        }

    }

}





