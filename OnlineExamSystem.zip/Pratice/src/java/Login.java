/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.sql.Statement;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Joy
 */
public class Login extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
            String name = request.getParameter("username");
            String password = request.getParameter("pass");
            String c = request.getParameter("exist");

            Connection con = null;
            PreparedStatement ps = null;
            ResultSet rs = null;
            String q = null;
            if (c.equals("student")) {
                q = "SELECT * FROM JOYJFT.STUDENT WHERE USERNAME=? AND PASSWORD=?";
            } else {
                q = "SELECT * FROM JOYJFT.TEACHER WHERE USERNAME=? AND PASSWORD=?";

            }

            String dName = null;
            String dMail = null;
            String dUn = null;
            String dPass = null;
            String msg = null;

            try {
                Class.forName("org.apache.derby.jdbc.ClientDriver");
                con = DriverManager.getConnection("jdbc:derby://localhost:1527/MyDB", "joyjft", "12345");
                ps = con.prepareStatement(q);
                ps.setString(1, name);

                ps.setString(2, password);
                rs = ps.executeQuery();

                msg = "Invalid Login";

                User user = null;

                while (rs.next()) {
                    msg = "Successfull";

                    //Retrieve by column name
                    dUn = rs.getString("username");
                    dPass = rs.getString("password");
                    dMail = rs.getString("email");
                    dName = rs.getString("name");
                    user = new User(dName, dUn, dMail, dPass, c);
                    //Display values
                    System.out.println(dName + '\t' + dUn + '\t' + dMail + '\t' + dPass + '\t' + c);
                }
                if (msg.equals("Successfull")) {
                    request.getSession().setAttribute("status", "Successfull");

                    request.getSession().setAttribute("name", user.name);
                    request.getSession().setAttribute("un", user.username);
                    request.getSession().setAttribute("em", user.email);
                    request.getSession().setAttribute("pass", user.password);
                    request.getSession().setAttribute("type", user.type);

                    if (c.equals("student")) {
                        response.sendRedirect("studentPage.jsp");
                    } else {
                        response.sendRedirect("teacherPage.jsp");

                    }
                } else {
                    request.getSession().setAttribute("status", "Invalid");
                    if (c.equals("student")) {
                        response.sendRedirect("studentPage.jsp");
                    } else {
                        response.sendRedirect("teacherPage.jsp");

                    }

                }

            } catch (Exception e) {
                e.printStackTrace();

            }

        } catch (Exception ex) {
            ex.printStackTrace();
        }

    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);

    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}

//                request.getSession().setAttribute("name", user.name);
//                request.getSession().setAttribute("un", user.username);
//                request.getSession().setAttribute("em", user.email);
//                request.getSession().setAttribute("pass", user.password);
//                request.getSession().setAttribute("type", user.type);
//                
//                if (c.equals("student")) {
//                    response.sendRedirect("studentPage.jsp");
//                } else {
//                    response.sendRedirect("teacherPage.jsp");
//
//                }
